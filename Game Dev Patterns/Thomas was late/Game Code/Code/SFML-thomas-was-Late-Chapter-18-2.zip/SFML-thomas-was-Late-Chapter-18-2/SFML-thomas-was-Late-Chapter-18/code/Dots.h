#pragma once
#include "PlayableCharacter.h"


class Dots : public PlayableCharacter
{
public:
	// A constructor specific to Player
	Dots();

	// The overriden input handler for Player
    
   
};

#pragma once
