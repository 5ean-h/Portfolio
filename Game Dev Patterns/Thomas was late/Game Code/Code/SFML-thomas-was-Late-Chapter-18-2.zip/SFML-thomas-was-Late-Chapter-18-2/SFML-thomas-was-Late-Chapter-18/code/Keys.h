#include "PlayableCharacter.h"

class Keys : public PlayableCharacter
{
public:
	// A constructor specific to Player
	Keys();

};
#pragma once




