#include "PlayableCharacter.h"

class Coins : public PlayableCharacter
{
public:
	// A constructor specific to Player
	Coins();

	// The overriden input handler for Player


};

#pragma once