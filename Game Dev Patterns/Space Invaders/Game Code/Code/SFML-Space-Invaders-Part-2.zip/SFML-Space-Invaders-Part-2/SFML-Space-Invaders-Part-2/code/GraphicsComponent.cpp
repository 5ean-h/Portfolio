/*
All Functionality in GraphicsComponent.h
*/
