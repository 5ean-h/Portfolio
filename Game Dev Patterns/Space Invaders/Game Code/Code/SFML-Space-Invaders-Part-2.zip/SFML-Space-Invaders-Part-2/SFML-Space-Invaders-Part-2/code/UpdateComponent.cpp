/*
All Functionality in UpdateComponent.h
*/
