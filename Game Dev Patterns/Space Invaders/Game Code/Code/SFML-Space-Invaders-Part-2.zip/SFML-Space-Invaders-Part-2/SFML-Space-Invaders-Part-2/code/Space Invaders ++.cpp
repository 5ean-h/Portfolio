#include "GameEngine.h"

int main()
{
	GameEngine m_GameEngine;
	m_GameEngine.run();
	return 0;
}