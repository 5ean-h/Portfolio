#pragma once
#define debuggingOnConsole
class DevelopState {};
