#pragma once
#ifndef GameCharacter_H
#define GameCharacter_H

#include <iostream>
#include <string>
using namespace std;

class GameCharacter  //abstract class
{
	

public:
	void spawn(std::string typeID, int health, int speed, int x, int y);
	void render();
	virtual void update() = 0;
	void stats();
	bool isAlive();


protected:
	std::string m_typeID;
	int m_Health;
	int m_Speed;
	int m_x;
	int m_y;
	bool m_Alive;

};
#endif