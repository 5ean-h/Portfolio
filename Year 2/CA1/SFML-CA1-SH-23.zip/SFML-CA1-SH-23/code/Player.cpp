#include "Player.h"

void Player::spawn(std::string typeID, int health, int speed, int x, int y)
{

	m_typeID = typeID;
	m_Health = health;
	m_Speed = speed;
	m_x = x;
	m_y = y;


}
void Player::update()
{
		cout << "Enter the number for which direction your wish to go" << endl;
		cout << "1. North" << endl;
		cout << "2. South" << endl;
		cout << "3. East " << endl;
		cout << "4. West" << endl;

		int playerChoice;
		cin >> playerChoice;

		if (playerChoice == 1)
		{
			m_y -= m_y + 1;
		}
		else if (playerChoice == 2)
		{
			m_y += m_y - 1;
		}
		else if (playerChoice == 3)
		{
			m_x += m_x + 1;
		}
		else if (playerChoice == 4)
		{
			m_x -= m_x - 1;
		}
		if (m_x > 10 && m_x <= 0 && m_y > 10 && m_y <= 0)
		{
			m_x = m_x - 1;
			m_y = 5 - 1;
			m_Health = m_Health - (m_Speed * 2);
			cout << "You Hit corner and lost health" << endl;
	}

}

