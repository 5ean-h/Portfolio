#include "GameCharacter.h"
void GameCharacter::spawn(std::string typeID, int health, int speed, int x, int y)
{

	m_typeID = typeID;
	m_Health = health;
	m_Speed = speed;
	m_x = x;
	m_y = y;


}
void GameCharacter::render()
{
	cout << m_typeID << " (" << m_x << ", " << m_y << ") " << endl;
}
void GameCharacter::stats()
{
	cout << m_typeID << endl;
	cout << "Speed: " << m_Speed << endl;
	cout << "Health: " << m_Health << endl;
}
bool GameCharacter::isAlive()
{
	if (m_Health <= 0)
	{
		// dead
		m_Alive = false;

		return true;
	}

	//not dead yet
	return false;
}




