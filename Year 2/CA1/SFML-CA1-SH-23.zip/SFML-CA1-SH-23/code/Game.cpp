#include "Game.h"

void Game::init()
{
	GameCharacter* player = new Player();		//points to player obj
	GameCharacter* zombie = new Enemy();		//points to a enemy obj
	GameCharacter* vampire = new Enemy();		//points to a enemy obj
	GameCharacter* mummy = new Enemy();		//points to a enemy obj
	GameCharacter* ghost = new Enemy();		//points to a enemy obj
	

	player->GameCharacter::spawn("Player", 20, 30, 5, 5);
	zombie->GameCharacter::spawn("Zombie", 20, 30, 2, 1);
	vampire->GameCharacter::spawn("Vampire", 20, 30, 2, 1);
	mummy->GameCharacter::spawn("Mummy", 20, 30, 2, 1);
	ghost->GameCharacter::spawn("Ghost", 20, 30, 2, 1);


	srand((int)time(NULL));
	int playerHealth = (rand() % 30) + 140;
	int zombieHealth = (rand() % 60) + 90;
	int vampireHealth = (rand() % 60) + 90;
	int mummyHealth = (rand() % 60) + 90;

	int playerSpeed = (rand() % 2) + 2;
	int zombieSpeed = (rand() % 2) + 1;
	int vampireSpeed = (rand() % 2) + 1;
	int mummySpeed = (rand() % 2) + 1;


	
	lpGameCharacters.push_back(player);		//added player to the list
	lpGameCharacters.push_back(zombie);		//added an enemy to the list
	lpGameCharacters.push_back(vampire);		//added an enemy to the list
	lpGameCharacters.push_back(mummy);		//added an enemy to the list
	lpGameCharacters.push_back(ghost);		//added an enemy to the list
	
	


};
void Game::render()
{
	
	list<GameCharacter*>::const_iterator iter;
	for (iter = lpGameCharacters.begin(); iter != lpGameCharacters.end(); ++iter)
	{
		(*iter)->GameCharacter::render();

	}

};
void Game::update()
{
	list<GameCharacter*>::const_iterator iter;
	for (iter = lpGameCharacters.begin(); iter != lpGameCharacters.end(); ++iter)
	{
		(*iter)->GameCharacter::update();

	}
};
void Game::battle()
{

};
void Game::stats()
{
	list<GameCharacter*>::const_iterator iter;
	for (iter = lpGameCharacters.begin(); iter != lpGameCharacters.end(); ++iter)
	{
		(*iter)->GameCharacter::stats();

	}
};
void Game::clean()
{

};

