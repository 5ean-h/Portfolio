#pragma once
#ifndef GAME_H
#define GAME_H
#include "GameCharacter.h"
#include "Player.h"
#include "Enemy.h"
#include <vector>
#include <list>

class Game : public GameCharacter
{
	public:

		
		void init();
		void render();
		void update();
		void battle();
		void stats();
		void clean();


	protected:
		GameCharacter* player;		//points to player obj
		GameCharacter* zombie;		//points to a enemy obj
		GameCharacter* vampire;		//points to a enemy obj
		GameCharacter* mummy;		//points to a enemy obj
		GameCharacter* ghost;		//points to a enemy obj
		list<GameCharacter*> lpGameCharacters;

};
#endif