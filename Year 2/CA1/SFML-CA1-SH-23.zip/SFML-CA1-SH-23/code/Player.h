#pragma once

#ifndef Player_H
#define Player_H

#include "GameCharacter.h"

class Player : public GameCharacter {

	void spawn(std::string typeID, int health, int speed, int x, int y);
	void update();
	

};
#endif