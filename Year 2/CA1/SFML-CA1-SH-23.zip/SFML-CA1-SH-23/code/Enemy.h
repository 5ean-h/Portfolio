#pragma once

#ifndef Enemy_H
#define Enemy_H

#include "GameCharacter.h"

class Enemy : public GameCharacter {

	void spawn(std::string typeID, int health, int speed, int x, int y);
	void update();



};
#endif