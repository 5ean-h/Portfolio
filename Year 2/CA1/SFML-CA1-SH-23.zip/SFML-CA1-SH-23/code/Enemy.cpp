#include "Enemy.h"

void Enemy::spawn(std::string typeID, int health, int speed, int x, int y)
{
	m_typeID = typeID;
	m_Health = health;
	m_Speed = speed;
	m_x = x;
	m_y = y;
}

void Enemy::update()
{
	srand((int)time(NULL));
	int direction = (rand() % 3) + 1;
	int random = (rand() % 9) + 1;

	if (random >= 8)
	{
		random = 1;
	}
	else
	{
		random = 0;
	}




	if (direction == 1)
	{
		m_y -= m_y + random;
	}
	else if (direction == 2)
	{
		m_y += m_y - random;
	}
	else if (direction == 3)
	{
		m_x += m_x + random;
	}
	else if (direction == 4)
	{
		m_x -= m_x - random;
	}

	if (m_x > 10 && m_x <= 0 && m_y > 10 && m_y <= 0)
	{
		m_x = 1;
		m_y = 1;
		m_Health = m_Health - (m_Speed * 3);
		cout << m_typeID << " Hit corner and lost health" << endl;
	}

}

