#include "Player.h"
#include "Enemy.h"
#include "Game.h"
#include <vector>
#include <list>


int main()
{

	Game game;
	game.init();

	
	cout << "Using a list to cycle through all the Creatures \n";
	for (int i = 0; i < 50; i++)
	{

		game.render();
		game.update();
		game.battle();
		game.stats();
		game.clean();




	}//end of for loop 50 times
	game.stats();

	return 0;
}